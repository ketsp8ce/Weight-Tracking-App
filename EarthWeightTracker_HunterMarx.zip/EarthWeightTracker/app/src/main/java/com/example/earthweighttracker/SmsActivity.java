//java outline for sms notification activity
package com.example.earthweighttracker;

//import relevent methods and views
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

//import androidx libraries
import androidx.appcompat.app.AppCompatActivity; //base class
import androidx.core.app.ActivityCompat; //used for runtime permissions
import androidx.core.content.ContextCompat; //used for permission checks

// import android system services
import android.Manifest; //contains permission constants
import android.content.pm.PackageManager; // used for permission status checks

public class SmsActivity extends AppCompatActivity {

    // declare views
    private Button btnEnableSMS;
    private TextView textViewStatus;

    private static final int SMS_PERMISSION_CODE = 101; //request code for SMS permissions

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        // initialize views
        btnEnableSMS = findViewById(R.id.btnEnableSMS);
        textViewStatus = findViewById(R.id.textViewStatus);

        btnEnableSMS.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            } else {
                textViewStatus.setText("Status: Enabled");
                //send sms here
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            }
        });
    }
            @Override
                  public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
            {
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == SMS_PERMISSION_CODE) {
                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                        textViewStatus.setText("Status: Enabled");
                        Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                    } else {
                        textViewStatus.setText("Status: Disabled");
                        Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    }












