//java outline for main activity

package com.example.earthweighttracker;

//import relavent methods and views
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.database.Cursor;

//android content library for launching new activities
import android.content.Intent;

//import base class
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    // declare views
    private LinearLayout dataContainer;
    private Button buttonAdd;
    private WeightDatabase weightDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dataContainer = findViewById(R.id.dataContainer);
        buttonAdd = findViewById(R.id.buttonAdd);
        weightDatabase = new WeightDatabase(this);

        loadWeights();

        buttonAdd.setOnClickListener(v -> {
            startActivity(new Intent(this, AddActivity.class));
        });

    }
    @Override
    protected void onResume() {
    super.onResume();
    loadWeights();
    }

    private void loadWeights() {
        dataContainer.removeAllViews();
        Cursor cursor = weightDatabase.getAllWeights();

        while(cursor.moveToNext()) {
            View rowView = getLayoutInflater().inflate(R.layout.weight_row, dataContainer, false);

            TextView tvDate = rowView.findViewById(R.id.rowDate);
            TextView tvWeight = rowView.findViewById(R.id.rowWeight);
Button btnDelete = rowView.findViewById(R.id.rowDelete);

tvDate.setText(cursor.getString(1));
tvWeight.setText(String.format("%.1f lbs", cursor.getDouble(2)));

final long id = cursor.getLong(0);
btnDelete.setOnClickListener(v -> {
    if (weightDatabase.deleteWeight(id)) {
        loadWeights();
    }
});
dataContainer.addView(rowView);
        }
        cursor.close();
    }
}