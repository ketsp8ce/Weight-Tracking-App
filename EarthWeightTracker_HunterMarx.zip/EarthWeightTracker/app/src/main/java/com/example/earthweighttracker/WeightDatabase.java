package com.example.earthweighttracker;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.content.Context;


public class WeightDatabase extends SQLiteOpenHelper {

    //database variables
    private static final String DATABASE_NAME = "EarthWeightTracker.db";
    private static final int VERSION = 1;

    // constructor
    public WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //generic weight table
    private static final class WeightTable {
        //declare column names
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

    //user's weight table
    private static final class UserLoginInfoTable {
        private static final String TABLE = "userLoginInfo";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_GOAL_WEIGHT = "goal_weight";
        private static final String COL_HEIGHT = "height";
        private static final String COL_AGE = "age";
    }


    @Override // called with creation of database
    public void onCreate(SQLiteDatabase db) {
        //SQL commands to generate weights table
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_DATE + " TEXT, " +  // stores date as string
                WeightTable.COL_WEIGHT + " REAL)"); // stores weight as decimal

        // SQL commands to generate user login info table
        db.execSQL("CREATE TABLE " + UserLoginInfoTable.TABLE + " (" +
                UserLoginInfoTable.COL_USERNAME + " TEXT PRIMARY KEY, " +
                UserLoginInfoTable.COL_PASSWORD + " TEXT, " +
                UserLoginInfoTable.COL_GOAL_WEIGHT + " REAL, " +  // Added
                UserLoginInfoTable.COL_HEIGHT + " TEXT, " +      // Added
                UserLoginInfoTable.COL_AGE + " INTEGER)");       // Added
         }


    @Override // called when upgrading database
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // drop previous existing weight table
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        //drop previous existing user login info table
        db.execSQL("DROP TABLE IF EXISTS " + UserLoginInfoTable.TABLE);
        // create new table
        onCreate(db);
    }

    // weight CRUD operations
    public boolean insertWeight(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, date);
        values.put(WeightTable.COL_WEIGHT, weight);
        long result = db.insert(WeightTable.TABLE, null, values);
        return result != -1;
    }
    public Cursor getAllWeights() {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(WeightTable.TABLE, null, null, null, null, null, WeightTable.COL_DATE + " DESC");
    }

    public boolean deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(WeightTable.TABLE, WeightTable.COL_ID + "=?", new String[]{String.valueOf(id)}) > 0;
    }

    // user authentication
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserLoginInfoTable.COL_USERNAME, username);
        values.put(UserLoginInfoTable.COL_PASSWORD, password);
        long result = db.insert(UserLoginInfoTable.TABLE, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(UserLoginInfoTable.TABLE,
                new String[]{UserLoginInfoTable.COL_USERNAME},
                UserLoginInfoTable.COL_USERNAME + "=? AND " + UserLoginInfoTable.COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public boolean saveUserProfile(String username, double goalWeight, String height, int age) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserLoginInfoTable.COL_GOAL_WEIGHT, goalWeight);
        values.put(UserLoginInfoTable.COL_HEIGHT, height);
        values.put(UserLoginInfoTable.COL_AGE, age);

        int rowsAffected = db.update(
                UserLoginInfoTable.TABLE,
                values,
                UserLoginInfoTable.COL_USERNAME + " = ?",
                new String[]{username}
        );
        return rowsAffected > 0;
    }

    public Cursor getUserProfile(String username) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(
                UserLoginInfoTable.TABLE,
                new String[]{
                        UserLoginInfoTable.COL_GOAL_WEIGHT,
                        UserLoginInfoTable.COL_HEIGHT,
                        UserLoginInfoTable.COL_AGE
                },
                UserLoginInfoTable.COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null
        );
    }
}



