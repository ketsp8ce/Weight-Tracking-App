//java outline for adding entries to the database actiivty

package com.example.earthweighttracker;

//import relavent methods and views
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast; //pop up message for user
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

//import base class
import androidx.appcompat.app.AppCompatActivity;


public class AddActivity extends AppCompatActivity {

    //delcare views
    private Button buttonSave;
    private EditText editDate;
    private EditText editWeight;
    private WeightDatabase weightDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        //pull views from layout
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        buttonSave = findViewById(R.id.buttonSave);
        weightDatabase = new WeightDatabase(this);

        // set current date as default value in date field *******************
        String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(new Date());
        editDate.setText(currentDate);

        // set click listener for save button ********
        buttonSave.setOnClickListener(v -> {
            String date = editDate.getText().toString().trim();
            String weightStr = editWeight.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    double weight = Double.parseDouble(weightStr);
                    if (weightDatabase.insertWeight(date, weight)) {
                        finish();
                    } else {
                        Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid weight", Toast.LENGTH_SHORT).show();
                }

                }
            });
        }
    }


